#' Snake-case aliases for the main EntraineR trainers
#'
#' @description
#' These aliases provide a homogeneous snake_case API while preserving the
#' historical function names for backwards compatibility.
#'
#' @param ... Passed to the corresponding historical trainer function.
#' @return Same return value as the corresponding trainer.
#' @name trainer_aliases
NULL

#' @rdname trainer_aliases
#' @export
trainer_aovsum <- function(...) trainer_AovSum(...)

#' @rdname trainer_aliases
#' @export
trainer_linear_model <- function(...) trainer_LinearModel(...)

#' @rdname trainer_aliases
#' @export
trainer_pca <- function(...) trainer_PCA(...)

#' @rdname trainer_aliases
#' @export
trainer_mca <- function(...) trainer_MCA(...)

#' @rdname trainer_aliases
#' @export
trainer_chisq <- function(...) trainer_chisq_test(...)

#' @rdname trainer_aliases
#' @export
trainer_cor <- function(...) trainer_cor_test(...)

#' @rdname trainer_aliases
#' @export
trainer_prop <- function(...) trainer_prop_test(...)

#' @rdname trainer_aliases
#' @export
trainer_var <- function(...) trainer_var_test(...)
